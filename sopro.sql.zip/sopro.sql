-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 07, 2013 at 07:35 PM
-- Server version: 5.5.25
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sopro`
--

-- --------------------------------------------------------

--
-- Table structure for table `brainstorming`
--

CREATE TABLE `brainstorming` (
  `id` varchar(150) NOT NULL,
  `nom` text NOT NULL,
  `description` text NOT NULL,
  `createur` text NOT NULL,
  `dateDebut` date NOT NULL,
  `heureDebut` time NOT NULL,
  `dureePhase1` time NOT NULL,
  `dureePhase2` time NOT NULL,
  `competences` text NOT NULL,
  `source` varchar(50) NOT NULL,
  `compterendu` text NOT NULL,
  `phase` int(11) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE `permission` (
  `brainstorm` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `admin` int(1) NOT NULL DEFAULT '0',
  `vote` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`brainstorm`,`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `nom` text NOT NULL,
  `prenom` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` text NOT NULL,
  `entreprise` text NOT NULL,
  `poste` text NOT NULL,
  `competences` text NOT NULL,
  `image` text NOT NULL,
  `linkedin` text NOT NULL,
  `viadeo` text NOT NULL,
  `twitter` text NOT NULL,
  `facebook` text NOT NULL,
  `googleplus` text NOT NULL,
  `drupalID` varchar(50) NOT NULL,
  `token` text NOT NULL,
  `activer` varchar(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email`),
  KEY `activer` (`activer`),
  KEY `activer_2` (`activer`),
  KEY `activer_3` (`activer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vote`
--

CREATE TABLE `vote` (
  `brainstorm` varchar(150) NOT NULL,
  `idea` varchar(10) NOT NULL,
  `nombre` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
